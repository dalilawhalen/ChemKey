import { pgTable, text, serial, integer, boolean, timestamp, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// User relations
export const usersRelations = relations(users, ({ many }) => ({
  savedFormulas: many(savedFormulas),
  formulaHistory: many(formulaHistory),
}));

// SavedFormulas table - for storing user's favorite formulas
export const savedFormulas = pgTable("saved_formulas", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(), // Name/title for the saved formula
  formula: text("formula").notNull(), // Raw formula input
  formattedFormula: text("formatted_formula").notNull(), // Formatted output
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSavedFormulaSchema = createInsertSchema(savedFormulas).pick({
  userId: true,
  name: true, 
  formula: true,
  formattedFormula: true,
});

export type InsertSavedFormula = z.infer<typeof insertSavedFormulaSchema>;
export type SavedFormula = typeof savedFormulas.$inferSelect;

// SavedFormulas relations
export const savedFormulasRelations = relations(savedFormulas, ({ one }) => ({
  user: one(users, {
    fields: [savedFormulas.userId],
    references: [users.id],
  }),
}));

// FormulaHistory table - for storing user's past formula calculations
export const formulaHistory = pgTable("formula_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  formula: text("formula").notNull(), // Raw formula input
  formattedFormula: text("formatted_formula").notNull(), // Formatted output
  isBalanced: boolean("is_balanced").default(false), // Whether this was a balanced equation
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertFormulaHistorySchema = createInsertSchema(formulaHistory).pick({
  userId: true,
  formula: true,
  formattedFormula: true,
  isBalanced: true,
});

export type InsertFormulaHistory = z.infer<typeof insertFormulaHistorySchema>;
export type FormulaHistory = typeof formulaHistory.$inferSelect;

// FormulaHistory relations
export const formulaHistoryRelations = relations(formulaHistory, ({ one }) => ({
  user: one(users, {
    fields: [formulaHistory.userId],
    references: [users.id],
  }),
}));
