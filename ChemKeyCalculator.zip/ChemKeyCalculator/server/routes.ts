import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSavedFormulaSchema, insertFormulaHistorySchema } from "@shared/schema";
import { z } from "zod";
import "./types"; // Import session type definitions

export async function registerRoutes(app: Express): Promise<Server> {
  // Base API route for checking server status
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "ChemKey server is running" });
  });

  // User authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already taken" });
      }
      
      // Create new user
      const user = await storage.createUser({ username, password });
      
      // Set user session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      res.json({ 
        success: true, 
        user: { id: user.id, username: user.username } 
      });
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Set user session
      if (req.session) {
        req.session.userId = user.id;
      }
      
      res.json({ 
        success: true, 
        user: { id: user.id, username: user.username } 
      });
    } catch (error) {
      console.error("Error logging in:", error);
      res.status(500).json({ error: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ error: "Failed to log out" });
        }
        res.json({ success: true });
      });
    } else {
      res.json({ success: true });
    }
  });

  // Check current user session
  app.get("/api/auth/me", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(401).json({ error: "User not found" });
      }
      
      res.json({ 
        success: true, 
        user: { id: user.id, username: user.username } 
      });
    } catch (error) {
      console.error("Error getting current user:", error);
      res.status(500).json({ error: "Failed to get current user" });
    }
  });

  // Saved formulas routes
  app.post("/api/formulas/save", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const formulaData = insertSavedFormulaSchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const savedFormula = await storage.saveFavoriteFormula(formulaData);
      res.json({ success: true, savedFormula });
    } catch (error) {
      console.error("Error saving formula:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid formula data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to save formula" });
    }
  });

  app.get("/api/formulas/saved", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const savedFormulas = await storage.getUserSavedFormulas(req.session.userId);
      res.json({ success: true, savedFormulas });
    } catch (error) {
      console.error("Error getting saved formulas:", error);
      res.status(500).json({ error: "Failed to get saved formulas" });
    }
  });

  app.delete("/api/formulas/saved/:id", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const formulaId = parseInt(req.params.id);
      if (isNaN(formulaId)) {
        return res.status(400).json({ error: "Invalid formula ID" });
      }
      
      await storage.deleteSavedFormula(formulaId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting formula:", error);
      res.status(500).json({ error: "Failed to delete formula" });
    }
  });

  // Formula history routes
  app.post("/api/formulas/history", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const historyData = insertFormulaHistorySchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const historyEntry = await storage.addFormulaToHistory(historyData);
      res.json({ success: true, historyEntry });
    } catch (error) {
      console.error("Error adding formula to history:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid history data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add formula to history" });
    }
  });

  app.get("/api/formulas/history", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const history = await storage.getUserFormulaHistory(req.session.userId, limit);
      res.json({ success: true, history });
    } catch (error) {
      console.error("Error getting formula history:", error);
      res.status(500).json({ error: "Failed to get formula history" });
    }
  });

  app.delete("/api/formulas/history", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      await storage.clearUserHistory(req.session.userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing formula history:", error);
      res.status(500).json({ error: "Failed to clear formula history" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
