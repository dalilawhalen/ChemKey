import { 
  users, savedFormulas, formulaHistory, 
  type User, type InsertUser,
  type SavedFormula, type InsertSavedFormula,
  type FormulaHistory, type InsertFormulaHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Formula saving functionality
  saveFavoriteFormula(formula: InsertSavedFormula): Promise<SavedFormula>;
  getUserSavedFormulas(userId: number): Promise<SavedFormula[]>;
  deleteSavedFormula(formulaId: number): Promise<void>;
  
  // Formula history functionality
  addFormulaToHistory(formulaHistory: InsertFormulaHistory): Promise<FormulaHistory>;
  getUserFormulaHistory(userId: number, limit?: number): Promise<FormulaHistory[]>;
  clearUserHistory(userId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Formula saving functionality
  async saveFavoriteFormula(formula: InsertSavedFormula): Promise<SavedFormula> {
    const [savedFormula] = await db.insert(savedFormulas).values(formula).returning();
    return savedFormula;
  }

  async getUserSavedFormulas(userId: number): Promise<SavedFormula[]> {
    return db.select()
      .from(savedFormulas)
      .where(eq(savedFormulas.userId, userId))
      .orderBy(desc(savedFormulas.createdAt));
  }

  async deleteSavedFormula(formulaId: number): Promise<void> {
    await db.delete(savedFormulas).where(eq(savedFormulas.id, formulaId));
  }

  // Formula history functionality
  async addFormulaToHistory(formula: InsertFormulaHistory): Promise<FormulaHistory> {
    const [historyItem] = await db.insert(formulaHistory).values(formula).returning();
    return historyItem;
  }

  async getUserFormulaHistory(userId: number, limit: number = 20): Promise<FormulaHistory[]> {
    return db.select()
      .from(formulaHistory)
      .where(eq(formulaHistory.userId, userId))
      .orderBy(desc(formulaHistory.createdAt))
      .limit(limit);
  }

  async clearUserHistory(userId: number): Promise<void> {
    await db.delete(formulaHistory).where(eq(formulaHistory.userId, userId));
  }
}

export const storage = new DatabaseStorage();
