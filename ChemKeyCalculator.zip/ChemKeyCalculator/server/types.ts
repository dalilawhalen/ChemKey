import 'express-session';

// Extend Express Session with our custom properties
declare module 'express-session' {
  interface SessionData {
    userId?: number;
  }
}