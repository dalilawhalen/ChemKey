import { useState, useEffect } from "react";
import FormulaInput from "@/components/ChemKey/FormulaInput";
import FormulaOutput from "@/components/ChemKey/FormulaOutput";
import ActionButtons from "@/components/ChemKey/ActionButtons";
import ExamplesSection from "@/components/ChemKey/ExamplesSection";
import ThemeToggle from "@/components/ThemeToggle";
import SaveFormulaDialog from "@/components/ChemKey/SaveFormulaDialog";
import SavedFormulas from "@/components/ChemKey/SavedFormulas";
import { formatFormula } from "@/lib/utils/formatter";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/useAuth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Home() {
  const [formulaInput, setFormulaInput] = useState("");
  const [formattedOutput, setFormattedOutput] = useState("");
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    if (formulaInput.trim()) {
      setFormattedOutput(formatFormula(formulaInput.trim()));
    } else {
      setFormattedOutput("");
    }
  }, [formulaInput]);

  const handleExampleClick = (example: string) => {
    setFormulaInput(example);
  };

  const handleBalanceReaction = () => {
    // Balancing happens within the ActionButtons component
    // This is just for confirmation
    if (!formulaInput.includes("->") && !formulaInput.includes("→")) {
      toast({
        title: "Invalid Reaction",
        description: "Please enter a chemical reaction with an arrow (->).",
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  // Track formula in history when it changes
  useEffect(() => {
    const addToHistory = async () => {
      if (!isAuthenticated || !formulaInput.trim() || !formattedOutput) return;
      
      try {
        // Add to history
        await apiRequest({
          path: "/api/formulas/history",
          method: "POST",
          body: JSON.stringify({
            formula: formulaInput,
            formattedOutput,
            isBalanced: formulaInput.includes("->") || formulaInput.includes("→")
          }),
          headers: {
            "Content-Type": "application/json",
          }
        });
        
        // Invalidate history query if it's being viewed
        queryClient.invalidateQueries({ queryKey: ["/api/formulas/history"] });
      } catch (error) {
        // Silently fail, we don't want to interrupt user experience
        console.error("Failed to add to history:", error);
      }
    };
    
    // Debounce history tracking to avoid excessive API calls
    const timeoutId = setTimeout(() => {
      addToHistory();
    }, 1500);
    
    return () => clearTimeout(timeoutId);
  }, [formulaInput, formattedOutput, isAuthenticated]);

  return (
    <>
      <Helmet>
        <title>ChemKey Smart Formatter 🧪</title>
        <meta name="description" content="Format chemical formulas with proper subscripts and superscripts, balance chemical equations, and export results." />
      </Helmet>
      
      <div className="min-h-screen bg-[#f0faf9] dark:bg-[#1e1e1e] transition-colors duration-300 p-4 md:p-6">
        <div className="max-w-2xl mx-auto bg-background rounded-xl shadow-md overflow-hidden transition-colors">
          <div className="p-4 md:p-6">
            <div className="flex justify-between items-center mb-4">
              <h1 className="text-2xl font-semibold flex items-center">
                <span>ChemKey</span>
                <span className="ml-2 text-[#3cbcb4]">🧪</span>
              </h1>
              <div className="flex items-center gap-3">
                <SaveFormulaDialog 
                  formula={formulaInput}
                  formattedFormula={formattedOutput}
                />
                <ThemeToggle />
              </div>
            </div>
            
            <p className="text-muted-foreground mb-6">
              Smart formatter for chemical formulas and equations with proper subscripts and superscripts
            </p>
            
            <Tabs defaultValue="editor" className="mb-6">
              <TabsList className="mb-4">
                <TabsTrigger value="editor">Formula Editor</TabsTrigger>
                {isAuthenticated && (
                  <TabsTrigger value="saved">Saved Formulas</TabsTrigger>
                )}
              </TabsList>
              
              <TabsContent value="editor">
                <FormulaInput 
                  value={formulaInput} 
                  onChange={(e) => setFormulaInput(e.target.value)} 
                />
                
                {formattedOutput && (
                  <FormulaOutput formattedOutput={formattedOutput} />
                )}
                
                <ActionButtons 
                  formula={formulaInput}
                  formattedOutput={formattedOutput}
                  onUpdateFormula={setFormulaInput}
                  onBalanceCheck={handleBalanceReaction}
                />
              </TabsContent>
              
              {isAuthenticated && (
                <TabsContent value="saved">
                  <div className="mb-4">
                    <h3 className="text-lg font-medium mb-2">Your Saved Formulas</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Click on a formula to load it into the editor.
                    </p>
                    <SavedFormulas onSelectFormula={setFormulaInput} />
                  </div>
                </TabsContent>
              )}
            </Tabs>
          </div>
          
          <ExamplesSection onExampleClick={handleExampleClick} />
        </div>
        <Toaster />
      </div>
    </>
  );
}
