import { Link } from "wouter";
import { ArrowRight, Beaker, BookOpen, FlaskConical, GraduationCap, LayoutList, LucideBeaker, Ruler, ScrollText, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";

export default function Landing() {
  return (
    <>
      <Helmet>
        <title>ChemKey - Chemical Formula Formatter & Equation Balancer</title>
        <meta name="description" content="ChemKey helps students, teachers, and researchers format chemical formulas and balance equations with a user-friendly interface." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-b from-background to-muted">
        {/* Hero Section */}
        <header className="container mx-auto py-12 md:py-24 flex flex-col items-center text-center space-y-8">
          <div className="flex items-center justify-center">
            <Beaker className="h-12 w-12 mr-2 text-primary" />
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
              Chem<span className="text-primary">Key</span>
            </h1>
          </div>
          
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl">
            The intelligent chemical formula formatter and equation balancer for students, educators, and researchers
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center">
            <Button asChild size="lg" className="gap-2">
              <Link href="/app">
                Launch App
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg">
              <a href="#how-to-use">How to Use</a>
            </Button>
          </div>
          
          <div className="bg-card p-6 rounded-lg shadow-lg max-w-2xl mx-auto border mt-8">
            <h3 className="text-xl font-semibold mb-3">Do you need to:</h3>
            <ul className="space-y-2 text-left list-disc pl-6">
              <li>Format chemical formulas with proper subscripts and superscripts?</li>
              <li>Balance chemical equations automatically?</li>
              <li>Convert common compound names to their chemical formulas?</li>
              <li>Save and export your chemical formulas for reports and assignments?</li>
            </ul>
            <p className="mt-4 font-medium">ChemKey makes chemistry notation simple!</p>
          </div>
        </header>
        
        {/* How to Use Section */}
        <section id="how-to-use" className="container mx-auto py-16 space-y-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How to Use ChemKey</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              ChemKey transforms plain text chemical formulas into properly formatted equations with just a few clicks
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <FlaskConical className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Enter Your Formula</CardTitle>
                <CardDescription>
                  Type any chemical formula or equation using normal text
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Enter formulas like H2O, H2SO4, or C6H12O6. For ionic charges, use the ^ symbol: Fe^3+, SO4^2-
                </p>
                <div className="bg-muted p-3 rounded-md mt-3 font-mono text-xs">
                  H2 + O2 {"->"} H2O
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <Zap className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Instant Formatting</CardTitle>
                <CardDescription>
                  See your formula convert with proper subscripts and superscripts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  ChemKey instantly transforms your input with proper formatting for subscripts, superscripts, and reaction arrows.
                </p>
                <div className="bg-muted p-3 rounded-md mt-3">
                  H₂ + O₂ → H₂O
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <LayoutList className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Use Common Names</CardTitle>
                <CardDescription>
                  Type common compound names instead of formulas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Enter compound names like "sodium hydroxide" or "sulfuric acid" and ChemKey will convert them to their formulas.
                </p>
                <div className="bg-muted p-3 rounded-md mt-3 space-y-2 text-xs">
                  <div>sodium hydroxide → NaOH</div>
                  <div>sulfuric acid → H₂SO₄</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <ScrollText className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Balance Equations</CardTitle>
                <CardDescription>
                  Automatically balance chemical equations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Enter an unbalanced equation and click "Balance Reaction" to get the balanced version with proper coefficients.
                </p>
                <div className="bg-muted p-3 rounded-md mt-3 space-y-2 text-xs">
                  <div>H₂ + O₂ {"->"} H₂O</div>
                  <div className="text-primary">2H₂ + O₂ {"->"} 2H₂O</div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <BookOpen className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Save and Export</CardTitle>
                <CardDescription>
                  Save favorite formulas and export as images
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Create an account to save frequently used formulas. Export your formatted equations as PNG or PDF for reports and assignments.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <GraduationCap className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Learning Resources</CardTitle>
                <CardDescription>
                  Use the built-in examples to learn formatting
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Browse through our example formulas and equations to see how different chemical notations should be formatted.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* For whom section */}
        <section className="container mx-auto py-16 bg-card rounded-lg my-12 shadow-md border">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Who Can Benefit from ChemKey?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              ChemKey is designed for anyone working with chemical formulas and equations
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-6">
            <div className="text-center space-y-4">
              <div className="mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center">
                <GraduationCap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Students</h3>
              <p className="text-sm text-muted-foreground">
                Perfect for chemistry homework, lab reports, and exam preparation. Save time formatting formulas and focus on understanding the chemistry concepts.
              </p>
            </div>
            
            <div className="text-center space-y-4">
              <div className="mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Teachers</h3>
              <p className="text-sm text-muted-foreground">
                Create professional-looking teaching materials, worksheets, and presentations with properly formatted chemical equations. Save and reuse common formulas.
              </p>
            </div>
            
            <div className="text-center space-y-4">
              <div className="mx-auto bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center">
                <Ruler className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold">Researchers</h3>
              <p className="text-sm text-muted-foreground">
                Quickly format complex chemical formulas for papers, presentations, and documentation. Export high-quality images for publication-ready documents.
              </p>
            </div>
          </div>
        </section>
        
        {/* Did you know section */}
        <section className="container mx-auto py-16 space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Did You Know?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Interesting facts about chemical notation and formulas
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">The Origin of Chemical Symbols</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Modern chemical symbols were introduced by Swedish chemist Jöns Jacob Berzelius in the early 19th century. 
                  He suggested using one or two letters from the element's name, making chemistry notation much more standardized.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Some Elements Have Ancient Symbols</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Several elements have symbols that come from their Latin or Greek names, not their English names: 
                  Gold (Au from "aurum"), Silver (Ag from "argentum"), Iron (Fe from "ferrum"), and Lead (Pb from "plumbum").
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">The Arrow Evolution</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  The reaction arrow (→) was first introduced by Dutch chemist Jacobus Henricus van 't Hoff in 1884. 
                  Before that, equals signs or verbal descriptions were used to indicate chemical reactions.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Superscripts and Subscripts Matter</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  A tiny formatting mistake can completely change the meaning of a chemical formula! 
                  For example, CO (carbon monoxide) is very different from CO₂ (carbon dioxide). 
                  One is a deadly gas, while the other is what we exhale.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* CTA section */}
        <section className="container mx-auto py-16 text-center">
          <div className="max-w-2xl mx-auto bg-primary/10 p-8 rounded-lg border border-primary/20">
            <h2 className="text-2xl font-bold mb-4">Ready to simplify your chemical formulas?</h2>
            <p className="mb-6 text-muted-foreground">
              Start using ChemKey today and never worry about formatting chemical equations again.
            </p>
            <Button asChild size="lg" className="gap-2">
              <Link href="/app">
                Get Started Now
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
        
        {/* Footer */}
        <footer className="border-t bg-muted/50 py-6">
          <div className="container mx-auto text-center text-sm text-muted-foreground">
            <div className="flex items-center justify-center mb-2">
              <Beaker className="h-5 w-5 mr-1 text-primary" />
              <span className="font-medium">ChemKey</span>
            </div>
            <p>© {new Date().getFullYear()} ChemKey. All rights reserved.</p>
            <p className="mt-1">The chemical formula formatter for students, teachers, and researchers.</p>
          </div>
        </footer>
      </div>
    </>
  );
}