import { Button } from "@/components/ui/button";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";
import { useToast } from "@/hooks/use-toast";
import { balanceChemicalEquation } from "@/lib/utils/formatter";

interface ActionButtonsProps {
  formula: string;
  formattedOutput: string;
  onUpdateFormula: (formula: string) => void;
  onBalanceCheck: () => boolean;
}

export default function ActionButtons({
  formula,
  formattedOutput,
  onUpdateFormula,
  onBalanceCheck,
}: ActionButtonsProps) {
  const { toast } = useToast();

  const downloadAsImage = async () => {
    if (!formattedOutput.trim()) {
      toast({
        title: "Empty Formula",
        description: "Please enter a formula first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const outputElement = document.getElementById("output");
      if (!outputElement) return;

      const canvas = await html2canvas(outputElement);
      const link = document.createElement("a");
      link.download = "chemkey_formula.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
      
      toast({
        title: "Success",
        description: "Image downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export as image. Please try again.",
        variant: "destructive",
      });
    }
  };

  const downloadAsPDF = async () => {
    if (!formattedOutput.trim()) {
      toast({
        title: "Empty Formula",
        description: "Please enter a formula first.",
        variant: "destructive",
      });
      return;
    }

    try {
      const outputElement = document.getElementById("output");
      if (!outputElement) return;

      const canvas = await html2canvas(outputElement);
      const imgData = canvas.toDataURL("image/png");
      
      const pdf = new jsPDF();
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save("chemkey_formula.pdf");
      
      toast({
        title: "Success",
        description: "PDF downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export as PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const balanceReaction = () => {
    if (!onBalanceCheck()) return;
    
    try {
      const balanced = balanceChemicalEquation(formula);
      onUpdateFormula(balanced);
      
      toast({
        title: "Balanced",
        description: "Chemical equation balanced successfully.",
      });
    } catch (err) {
      toast({
        title: "Balancing Failed",
        description: "Unable to balance this reaction. Please check your input.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex flex-wrap gap-3 justify-end">
      <Button
        variant="default"
        className="bg-[#3cbcb4] hover:bg-[#2ea69c] text-white"
        onClick={downloadAsImage}
      >
        <span className="mr-1">📷</span> Export as Image
      </Button>
      
      <Button
        variant="default"
        className="bg-[#3cbcb4] hover:bg-[#2ea69c] text-white"
        onClick={downloadAsPDF}
      >
        <span className="mr-1">📄</span> Export as PDF
      </Button>
      
      <Button
        variant="default"
        className="bg-[#3cbcb4] hover:bg-[#2ea69c] text-white"
        onClick={balanceReaction}
      >
        <span className="mr-1">⚖️</span> Balance Reaction
      </Button>
    </div>
  );
}
