import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import AuthDialog from "../Auth/AuthDialog";

interface SaveFormulaDialogProps {
  formula: string;
  formattedFormula: string;
}

export default function SaveFormulaDialog({ formula, formattedFormula }: SaveFormulaDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();
  
  const handleSave = async () => {
    if (!name.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for this formula",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    try {
      await apiRequest({
        path: "/api/formulas/save",
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          formula,
          formattedFormula
        }),
        headers: {
          "Content-Type": "application/json",
        }
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/formulas/saved"] });
      
      toast({
        title: "Formula saved",
        description: `"${name}" has been saved to your favorites`,
      });
      
      setOpen(false);
      setName("");
    } catch (error: any) {
      toast({
        title: "Failed to save",
        description: error.message || "There was an error saving your formula",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSuccess = () => {
    // Called after successful login/registration
    toast({
      title: "You're signed in",
      description: "Now you can save your formula",
    });
  };
  
  // If no formula, disable the button
  if (!formula || !formattedFormula) {
    return (
      <Button 
        variant="outline" 
        size="sm" 
        className="text-gray-500"
        disabled
      >
        Save Formula
      </Button>
    );
  }
  
  return isAuthenticated ? (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Save Formula
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Save Formula</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input 
              id="name" 
              value={name} 
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter a name for this formula"
            />
          </div>
          
          <div className="mt-2">
            <Label>Formula</Label>
            <div className="p-2 border rounded-md mt-1 font-mono bg-slate-50 dark:bg-slate-900 break-all">
              {formattedFormula}
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => setOpen(false)}
          >
            Cancel
          </Button>
          <Button 
            className="bg-[#3cbcb4] hover:bg-[#2ea69c] text-white"
            onClick={handleSave}
            disabled={isLoading}
          >
            {isLoading ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  ) : (
    <AuthDialog onSuccess={handleSuccess} />
  );
}