import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface SavedFormula {
  id: number;
  name: string;
  formula: string;
  formattedFormula: string;
  createdAt: string;
}

interface SavedFormulasProps {
  onSelectFormula: (formula: string) => void;
}

export default function SavedFormulas({ onSelectFormula }: SavedFormulasProps) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  // Query saved formulas
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/formulas/saved"],
    enabled: isAuthenticated,
    staleTime: 30000, // 30 seconds
  });
  
  // Delete formula mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest({
        path: `/api/formulas/saved/${id}`,
        method: "DELETE"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/formulas/saved"] });
      toast({
        title: "Formula deleted",
        description: "The formula has been removed from your saved list",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete the formula",
        variant: "destructive",
      });
    }
  });
  
  const handleDelete = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteMutation.mutate(id);
  };
  
  const handleSelect = (formula: string) => {
    onSelectFormula(formula);
  };
  
  if (!isAuthenticated) {
    return null; // Don't show anything if not authenticated
  }
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-4">
        <Spinner />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center text-red-500 py-2">
        Failed to load saved formulas
      </div>
    );
  }
  
  const savedFormulas = data?.savedFormulas || [];
  
  if (savedFormulas.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-2">
        No saved formulas yet
      </div>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
      {savedFormulas.map((formula: SavedFormula) => (
        <Card 
          key={formula.id} 
          className="cursor-pointer hover:border-[#3cbcb4] transition-colors"
          onClick={() => handleSelect(formula.formula)}
        >
          <CardHeader className="py-2 px-3">
            <div className="flex justify-between items-center">
              <CardTitle className="text-sm font-medium">{formula.name}</CardTitle>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-red-500 hover:text-red-700 hover:bg-red-100"
                onClick={(e) => handleDelete(formula.id, e)}
              >
                <Trash className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="py-2 px-3">
            <div className="bg-slate-50 dark:bg-slate-900 p-2 rounded font-mono text-sm break-all">
              {formula.formattedFormula}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}