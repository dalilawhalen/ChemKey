import { Button } from "@/components/ui/button";

interface ExamplesSectionProps {
  onExampleClick: (example: string) => void;
}

const examples = [
  {
    formula: "H2O",
    description: "Water"
  },
  {
    formula: "C6H12O6 + 6O2 -> 6CO2 + 6H2O",
    description: "Glucose combustion"
  },
  {
    formula: "Fe^3+",
    description: "Iron(III) ion"
  },
  {
    formula: "CO3^2-",
    description: "Carbonate ion"
  },
  {
    formula: "sulfuric acid",
    description: "Common name conversion"
  },
  {
    formula: "CH3COOH + NaOH -> CH3COONa + H2O",
    description: "Acid-base reaction"
  },
  {
    formula: "Na2CO3 + 2HCl -> 2NaCl + H2O + CO2",
    description: "Carbonate reaction"
  },
  {
    formula: "PO4^3-",
    description: "Phosphate ion"
  }
];

export default function ExamplesSection({ onExampleClick }: ExamplesSectionProps) {
  return (
    <div className="border-t border-gray-200 dark:border-gray-700 p-4 md:p-6 bg-gray-50 dark:bg-[#1a1a1a]">
      <h2 className="text-lg font-medium mb-3">Quick Examples</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {examples.map((example, index) => (
          <Button
            key={index}
            variant="outline"
            className="h-auto text-left p-2 text-sm bg-white dark:bg-[#262626] rounded border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors flex flex-col items-start"
            onClick={() => onExampleClick(example.formula)}
          >
            <div className="font-bold text-[#3cbcb4]">{example.formula}</div>
            <div className="text-gray-600 dark:text-gray-400">{example.description}</div>
          </Button>
        ))}
      </div>
    </div>
  );
}
