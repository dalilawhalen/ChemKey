import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface FormulaInputProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

export default function FormulaInput({ value, onChange }: FormulaInputProps) {
  return (
    <div className="mb-6">
      <Label htmlFor="input" className="block text-sm font-medium mb-2">
        Enter chemical formula or equation:
      </Label>
      <Textarea
        id="input"
        value={value}
        onChange={onChange}
        className="w-full h-24 px-4 py-3 rounded-lg border focus:border-[#3cbcb4] focus:ring focus:ring-[#3cbcb4]/20 transition-colors duration-200 text-base dark:border-gray-600 resize-y font-mono"
        placeholder="Examples: H2O, CaCO3, 2H2 + O2 -> 2H2O, Fe^3+, NH4OH..."
      />
    </div>
  );
}
