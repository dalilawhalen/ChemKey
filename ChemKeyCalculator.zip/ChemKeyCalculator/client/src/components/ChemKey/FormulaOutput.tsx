import { useRef, useEffect } from "react";

interface FormulaOutputProps {
  formattedOutput: string;
}

export default function FormulaOutput({ formattedOutput }: FormulaOutputProps) {
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Apply fade-in animation when the output changes
    if (outputRef.current) {
      outputRef.current.style.opacity = "0";
      setTimeout(() => {
        if (outputRef.current) {
          outputRef.current.style.opacity = "1";
        }
      }, 10);
    }
  }, [formattedOutput]);

  return (
    <div
      id="output"
      ref={outputRef}
      className="min-h-16 p-4 bg-[#f4fdfd] dark:bg-[#262626] rounded-lg border-l-4 border-[#3cbcb4] mb-6 text-lg font-medium whitespace-pre-wrap transition-opacity duration-300"
      style={{ opacity: 0 }}
    >
      {formattedOutput}
    </div>
  );
}
