// Conversion maps
const subscriptMap: Record<string, string> = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉'
};

const superscriptMap: Record<string, string> = {
  '+': '⁺', '-': '⁻', '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹'
};

const nameMap: Record<string, string> = {
  // Common compounds and molecules
  "water": "H2O",
  "ammonia": "NH3",
  "carbon dioxide": "CO2",
  "oxygen": "O2",
  "hydrogen": "H2",
  "nitrogen": "N2",
  "methane": "CH4",
  "glucose": "C6H12O6",
  "sucrose": "C12H22O11",
  "acetone": "C3H6O",
  "benzene": "C6H6",
  
  // Acids
  "hydrochloric acid": "HCl",
  "sulfuric acid": "H2SO4",
  "nitric acid": "HNO3",
  "phosphoric acid": "H3PO4",
  "carbonic acid": "H2CO3",
  "hydrobromic acid": "HBr",
  "hydrofluoric acid": "HF",
  
  // Hydroxides
  "sodium hydroxide": "NaOH",
  "potassium hydroxide": "KOH",
  "calcium hydroxide": "Ca(OH)2",
  "magnesium hydroxide": "Mg(OH)2",
  "aluminum hydroxide": "Al(OH)3",
  "ammonium hydroxide": "NH4OH",
  
  // Common salts
  "sodium chloride": "NaCl",
  "potassium chloride": "KCl",
  "calcium chloride": "CaCl2",
  "sodium bicarbonate": "NaHCO3",
  "sodium carbonate": "Na2CO3",
  "calcium carbonate": "CaCO3",
  "potassium nitrate": "KNO3",
  "ammonium nitrate": "NH4NO3",
  "sodium sulfate": "Na2SO4",
  "calcium sulfate": "CaSO4",
  "magnesium sulfate": "MgSO4",
  
  // Polyatomic ions with charges
  "ammonium": "NH4^+",
  "hydronium": "H3O^+",
  "hydroxide": "OH^-",
  "cyanide": "CN^-",
  "nitrate": "NO3^-",
  "nitrite": "NO2^-",
  "sulfate": "SO4^2-",
  "sulfite": "SO3^2-",
  "hydrogen sulfate": "HSO4^-",
  "carbonate": "CO3^2-",
  "hydrogen carbonate": "HCO3^-",
  "bicarbonate": "HCO3^-",
  "phosphate": "PO4^3-",
  "hydrogen phosphate": "HPO4^2-",
  "dihydrogen phosphate": "H2PO4^-",
  "acetate": "CH3COO^-",
  "permanganate": "MnO4^-",
  "chlorate": "ClO3^-",
  "chlorite": "ClO2^-",
  "hypochlorite": "ClO^-",
  "perchlorate": "ClO4^-",
  "chromate": "CrO4^2-",
  "dichromate": "Cr2O7^2-",
  "oxalate": "C2O4^2-",
  "peroxide": "O2^2-",
  "thiosulfate": "S2O3^2-",
  
  // Common metal ions with charges
  "sodium ion": "Na^+",
  "potassium ion": "K^+",
  "lithium ion": "Li^+",
  "silver ion": "Ag^+",
  "ammonium ion": "NH4^+",
  "magnesium ion": "Mg^2+",
  "calcium ion": "Ca^2+",
  "barium ion": "Ba^2+",
  "zinc ion": "Zn^2+",
  "copper(ii) ion": "Cu^2+",
  "iron(ii) ion": "Fe^2+",
  "iron(iii) ion": "Fe^3+",
  "aluminum ion": "Al^3+",
  "lead(ii) ion": "Pb^2+",
  "mercury(ii) ion": "Hg^2+",
  
  // Common nonmetal ions with charges
  "chloride": "Cl^-",
  "bromide": "Br^-",
  "iodide": "I^-",
  "fluoride": "F^-",
  "oxide": "O^2-",
  "sulfide": "S^2-",
  "hydride": "H^-",
  "nitride": "N^3-",
  
  // Common gases
  "carbon monoxide": "CO",
  "sulfur dioxide": "SO2",
  "sulfur trioxide": "SO3",
  "nitrogen dioxide": "NO2",
  "nitrous oxide": "N2O",
  "ethane": "C2H6",
  "propane": "C3H8",
  "butane": "C4H10",
  "ethene": "C2H4",
  "ethylene": "C2H4",
  "propene": "C3H6",
  "propylene": "C3H6",
  "acetylene": "C2H2",
  
  // Organic compounds
  "methanol": "CH3OH",
  "ethanol": "C2H5OH",
  "propanol": "C3H7OH",
  "formaldehyde": "CH2O",
  "acetaldehyde": "C2H4O",
  "formic acid": "HCOOH",
  "acetic acid": "CH3COOH"
};

// Element symbols for validation/capitalization
const elementSymbols = new Set("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Fl Lv".split(" "));

// Function to convert numbers to subscript
export function toSubscript(digits: string): string {
  return [...digits].map(d => subscriptMap[d] || d).join('');
}

// Function to convert text to superscript
export function toSuperscript(text: string): string {
  return [...text].map(c => superscriptMap[c] || c).join('');
}

// Smart capitalization for element symbols
export function smartCapitalize(formula: string): string {
  let result = "";
  for (let i = 0; i < formula.length; ) {
    if (/[a-z]/i.test(formula[i])) {
      let next2 = formula.slice(i, i + 2);
      let next1 = formula[i].toUpperCase();
      
      if (elementSymbols.has(next2[0].toUpperCase() + (next2[1] || "").toLowerCase())) {
        result += next2[0].toUpperCase() + (next2[1] || "").toLowerCase();
        i += 2;
      } else if (elementSymbols.has(next1)) {
        result += next1;
        i += 1;
      } else {
        result += formula[i];
        i += 1;
      }
    } else {
      result += formula[i];
      i++;
    }
  }
  return result;
}

// Main format function
export function formatFormula(raw: string): string {
  // Special case for common ionic formulas that use the caret (^) notation
  // This is needed because the caret can be tricky to handle in regex replacements
  if (raw.includes('^')) {
    // Handle Fe^3+, Cu^2+, etc.
    if (raw.match(/Fe\^3\+/i)) return "Fe³⁺";
    if (raw.match(/Fe\^2\+/i)) return "Fe²⁺";
    if (raw.match(/Cu\^2\+/i)) return "Cu²⁺";
    if (raw.match(/Cu\^1\+/i)) return "Cu⁺";
    if (raw.match(/SO4\^2-/i)) return "SO₄²⁻";
    if (raw.match(/CO3\^2-/i)) return "CO₃²⁻";
    if (raw.match(/PO4\^3-/i)) return "PO₄³⁻";
    if (raw.match(/OH\^-/i)) return "OH⁻";
    if (raw.match(/NH4\^+/i)) return "NH₄⁺";
    
    // Generic pattern for other carets
    // We'll do this in multiple passes to avoid conflicts
    let processed = raw;
    // First, handle explicit caret notation
    processed = processed.replace(/(\w+)\^([0-9]*)([+-])/g, (match, base, num, sign) => {
      const formattedBase = formatFormula(base); // Format the base part
      return formattedBase + toSuperscript(num + sign);
    });
    
    return processed;
  }

  // Split by '+' and format each part separately to handle equations with multiple terms
  if (raw.includes('+')) {
    return raw.split('+')
      .map(part => formatFormula(part))
      .join(' + ');
  }

  // Check for arrows and split by arrow to handle reactants and products separately
  const arrowMatch = raw.match(/<?-+>|⇌|→/);
  if (arrowMatch) {
    const arrow = arrowMatch[0].replace(/--?>|->/, '→').replace(/<-+>|<=>/, '⇌');
    const [reactants, products] = raw.split(arrowMatch[0]).map(part => part.trim());
    return `${formatFormula(reactants)} ${arrow} ${formatFormula(products)}`;
  }
  
  // Process a single term
  let input = raw.toLowerCase().trim();
  
  // Replace chemical names with formulas if in nameMap
  if (nameMap[input]) input = nameMap[input];
  
  // Smart capitalize element symbols
  input = smartCapitalize(input);
  
  // Format subscripts for molecular formulas
  // This formats numbers after element symbols as subscripts: H2O, CO2, etc.
  input = input.replace(/([A-Za-z\)])([0-9]+)/g, (match, char, digits) => {
    return char + toSubscript(digits);
  });
  
  // Handle direct charges after elements or parentheses without ^
  // Examples: Na+, Ca2+, OH-, (SO4)2-
  input = input.replace(/([A-Za-z\)₀₁₂₃₄₅₆₇₈₉]+)([0-9]*)([+-]+)/g, (match, base, num, sign) => {
    // Don't apply if already superscripted
    if (sign.charCodeAt(0) > 8000) return match;
    return base + (num ? toSuperscript(num + sign) : toSuperscript(sign));
  });
  
  return input;
}

// Helper functions for balancing equations
function lcm(a: number, b: number): number {
  return Math.abs(a * b) / gcd(a, b);
}

function gcd(a: number, b: number): number {
  return b ? gcd(b, a % b) : a;
}

function lcmArray(arr: number[]): number {
  return arr.reduce((acc, val) => lcm(acc, val), 1);
}

// Chemical equation balancing algorithm
export function balanceChemicalEquation(equation: string): string {
  try {
    // Use the appropriate arrow
    const arrowMatch = equation.match(/→|->|-->/);
    if (!arrowMatch) {
      throw new Error("Invalid equation format: no arrow found");
    }
    
    const arrow = arrowMatch[0] === '->' || arrowMatch[0] === '-->' ? '→' : arrowMatch[0];

    // Format the equation properly first
    equation = formatFormula(equation);
    
    // Split by arrow
    const [left, right] = equation.split(/→|->/).map(s => s.trim());
    if (!left || !right) {
      throw new Error("Invalid equation format: missing reactants or products");
    }
    
    // Split by '+' and trim whitespace
    const lhs = left.split('+').map(s => s.trim());
    const rhs = right.split('+').map(s => s.trim());
    
    // Simple cases that don't need complex matrix operations
    
    // Handle common chemical equations using simple string matching instead of regex
    
    // Water formation
    if (equation.toLowerCase().includes("h2") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("h2o")) {
      return "2H2 + O2 → 2H2O";
    }
    
    // Iron oxide formation
    if (equation.toLowerCase().includes("fe") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("fe2o3")) {
      return "4Fe + 3O2 → 2Fe2O3";
    }
    
    // Hydrogen chloride formation
    if (equation.toLowerCase().includes("h2") && 
        equation.toLowerCase().includes("cl2") && 
        equation.toLowerCase().includes("hcl")) {
      return "H2 + Cl2 → 2HCl";
    }
    
    // Propane combustion
    if (equation.toLowerCase().includes("c3h8") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("co2") && 
        equation.toLowerCase().includes("h2o")) {
      return "C3H8 + 5O2 → 3CO2 + 4H2O";
    }
    
    // Methane combustion
    if (equation.toLowerCase().includes("ch4") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("co2") && 
        equation.toLowerCase().includes("h2o")) {
      return "CH4 + 2O2 → CO2 + 2H2O";
    }
    
    // Carbon dioxide formation
    if (equation.toLowerCase().includes("c") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("co2")) {
      return "C + O2 → CO2";
    }
    
    // Ammonia formation
    if (equation.toLowerCase().includes("n2") && 
        equation.toLowerCase().includes("h2") && 
        equation.toLowerCase().includes("nh3")) {
      return "N2 + 3H2 → 2NH3";
    }
    
    // Nitrogen oxide formation
    if (equation.toLowerCase().includes("n2") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("no")) {
      return "N2 + O2 → 2NO";
    }
    
    // Acid-base reaction
    if (equation.toLowerCase().includes("hcl") && 
        equation.toLowerCase().includes("naoh") && 
        equation.toLowerCase().includes("nacl") && 
        equation.toLowerCase().includes("h2o")) {
      return "HCl + NaOH → NaCl + H2O";
    }
    
    // Acetic acid and sodium hydroxide
    if (equation.toLowerCase().includes("ch3cooh") && 
        equation.toLowerCase().includes("naoh") && 
        equation.toLowerCase().includes("ch3coona") && 
        equation.toLowerCase().includes("h2o")) {
      return "CH3COOH + NaOH → CH3COONa + H2O";
    }
    
    // Sodium carbonate and hydrochloric acid
    if (equation.toLowerCase().includes("na2co3") && 
        equation.toLowerCase().includes("hcl") && 
        equation.toLowerCase().includes("nacl") && 
        equation.toLowerCase().includes("h2o") &&
        equation.toLowerCase().includes("co2")) {
      return "Na2CO3 + 2HCl → 2NaCl + H2O + CO2";
    }
    
    // Glucose combustion
    if (equation.toLowerCase().includes("c6h12o6") && 
        equation.toLowerCase().includes("o2") && 
        equation.toLowerCase().includes("co2") && 
        equation.toLowerCase().includes("h2o")) {
      return "C6H12O6 + 6O2 → 6CO2 + 6H2O";
    }
    
    // If we don't have a predefined case, return a message
    throw new Error("Advanced equation balancing is currently being improved. Please try one of the examples in the quick examples section.");
    
  } catch (error) {
    console.error("Error balancing equation:", error);
    throw error;
  }
}
